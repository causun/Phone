package com.example.mobilestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobilestoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
