package com.example.mobilestore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobilestoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobilestoreApplication.class, args);
	}

}
